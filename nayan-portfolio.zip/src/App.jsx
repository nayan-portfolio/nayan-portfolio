import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <nav className="bg-white shadow p-4 flex justify-between items-center">
        <h1 className="text-xl font-bold">Nayan Ghosh</h1>
        <ul className="flex gap-4">
          <li><a href="#projects" className="hover:text-blue-600">Projects</a></li>
          <li><a href="#impact" className="hover:text-blue-600">Impact</a></li>
          <li><a href="#demo" className="hover:text-blue-600">Demo</a></li>
          <li>
            <a 
              href="/Nayan_Ghosh_Product_Manager_Resume.pdf" 
              download
              className="text-white bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded"
            >
              Download Resume
            </a>
          </li>
        </ul>
      </nav>

      <header className="text-center py-10">
        <h2 className="text-4xl font-bold mb-2">Product Manager | Data-Driven Strategist | Agile Leader</h2>
      </header>

      <section id="projects" className="max-w-4xl mx-auto mb-12 p-6">
        <h2 className="text-2xl font-semibold mb-4 border-b pb-2">Key Projects</h2>
        <ul className="space-y-6">
          <li>
            <h3 className="text-xl font-bold">Amazon Promo Financing Expansion</h3>
            <p>
              Launched Amazon Promo Financing for Chase-Amazon cardholders, allowing promo offers on third-party sites via Amazon Pay. Generated ~$62M in new revenue.
            </p>
          </li>
          <li>
            <h3 className="text-xl font-bold">Automated Rebill Processing</h3>
            <p>
              Streamlined dispute-related rebill transactions using FTM module enhancements. Eliminated manual intervention and saved $1.2M annually.
            </p>
          </li>
          <li>
            <h3 className="text-xl font-bold">6-Month Review Process Modernization</h3>
            <p>
              Migrated legacy mainframe process to AWS and implemented decision logic in Sapiens to enhance efficiency.
            </p>
          </li>
          <li>
            <h3 className="text-xl font-bold">Campaign QA & Delivery Optimization</h3>
            <p>
              Delivered 400+ marketing campaigns with zero production errors. Improved campaign speed to market by 30% through targeting logic improvements.
            </p>
          </li>
        </ul>
      </section>

      <section id="impact" className="max-w-4xl mx-auto mb-12 p-6">
        <h2 className="text-2xl font-semibold mb-4 border-b pb-2">Impact Highlights</h2>
        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <li className="bg-white p-4 rounded-xl shadow">
            <h4 className="text-lg font-bold">$62M</h4>
            <p>Revenue from Amazon Promo Financing</p>
          </li>
          <li className="bg-white p-4 rounded-xl shadow">
            <h4 className="text-lg font-bold">$1.2M</h4>
            <p>Annual savings from automated rebill workflows</p>
          </li>
          <li className="bg-white p-4 rounded-xl shadow">
            <h4 className="text-lg font-bold">30%</h4>
            <p>Faster campaign go-live via targeting enhancements</p>
          </li>
          <li className="bg-white p-4 rounded-xl shadow">
            <h4 className="text-lg font-bold">400+</h4>
            <p>Zero-error campaigns delivered across multiple LOBs</p>
          </li>
        </ul>
      </section>

      <section id="demo" className="max-w-4xl mx-auto mb-12 p-6">
        <h2 className="text-2xl font-semibold mb-4 border-b pb-2">Project Demo</h2>
        <div className="aspect-w-16 aspect-h-9">
          <iframe
            className="w-full h-72 rounded-xl"
            src="https://www.youtube.com/embed/dQw4w9WgXcQ"
            title="Project Demo"
            allowFullScreen
          ></iframe>
        </div>
      </section>

      <footer className="text-center text-sm text-gray-500 p-6">
        <p>Connect: nayangh@gmail.com | Mumbai, India</p>
      </footer>
    </div>
  );
}
